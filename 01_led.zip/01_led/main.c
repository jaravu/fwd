#include "led_blink.h"
void main()
{
	led_blink();
}
