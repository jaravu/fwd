#include <stdio.h>
#include <stdint.h>
#include "stm32f4xx.h"
#include "tim.h"
int main(void)
{

	tim2_pa5_output_compare();
	while(1)
	{

	}

}
