
#include "stm32f4xx.h"
#include "Systick.h"

int main(void) {
	   systick();
}
